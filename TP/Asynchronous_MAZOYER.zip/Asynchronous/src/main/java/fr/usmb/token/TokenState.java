package fr.usmb.token;

public enum TokenState {
    NULL, REQUEST, CRITICAL_SECTION, RELEASE
}
