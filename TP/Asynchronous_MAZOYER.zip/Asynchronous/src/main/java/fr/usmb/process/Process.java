package fr.usmb.process;

import com.google.common.eventbus.Subscribe;
import fr.usmb.EventBusService;
import fr.usmb.messages.*;
import fr.usmb.token.TokenState;

/**
 * This class represents a process that runs in a separate thread and communicates with other
 * processes using an event bus. It implements the Runnable interface to allow multi-threading.
 */
public class Process implements Runnable {

    public static final int maxNbProcess = 3; // Constant for max number of processes
    private static int nbProcess = 0; // Static counter to assign unique IDs to processes

    private final Thread thread;
    private EventBusService bus;

    private boolean alive;
    private boolean dead;
    private TokenState state;

    private final LamportClock clock;

    private boolean isCoordinator;
    private int syncCounter;

    private final int id = Process.nbProcess++;

    public Process(String name) {
        this.isCoordinator = false;

        this.bus = EventBusService.getInstance();
        this.bus.registerSubscriber(this);

        this.thread = new Thread(this);
        this.thread.setName(name);

        this.alive = true;
        this.dead = false;

        this.state = TokenState.NULL;

        this.clock = new LamportClock();

        this.syncCounter = 0;

        this.thread.start();
    }

    /**
     * Method to handle broadcast messages.
     * @param message {@link BroadcastMessage} The message to handle.
     */
    @Subscribe
    public void onBroadcast(BroadcastMessage<?> message) {
        clock.update(message.getTimestamp());
        if(message.getSender().equalsIgnoreCase(this.thread.getName())) return;
        info("Receiving broadcast message: " + message.getMessage() + " from " + message.getSender());
    }

    /**
     * Method to handle dedicated messages.
     * @param message {@link DedicatedMessage} The message to handle.
     */
    @Subscribe
    public void onReceive(DedicatedMessage<?> message) {
        clock.update(message.getTimestamp());
        if(!message.getReceiver().equalsIgnoreCase(this.thread.getName())) return;
        info("Receiving message: " + message.getMessage() + " from " + message.getSender());
    }

    /**
     * This method is triggered when the tokenMessage is received.
     */
    @Subscribe
    private void onToken(TokenMessage<?> tokenMessage) throws InterruptedException {
        clock.update(tokenMessage.getTimestamp());
        if(!tokenMessage.getToken().getHolder().equalsIgnoreCase(this.thread.getName())) return;

        if(this.state == TokenState.REQUEST){
            this.state = TokenState.CRITICAL_SECTION;
            while (this.state != TokenState.RELEASE){
                Thread.sleep(500);
            }
            info("Releasing the token");
        }

        sendTokenToNextProcess(tokenMessage);
    }

    /**
     * This method will request the token. And stop the process until the token is received.
     */
    public void requestSC() throws InterruptedException{
        this.state = TokenState.REQUEST;
        while (this.state == TokenState.REQUEST){
            Thread.sleep(500);
        }
    }

    /**
     * This method will release the token.
     */
    public void release(){
        this.state = TokenState.RELEASE;
    }



    /**
     * Run method for the process. This method is called when the thread is started.
     * It will run until the alive flag is set to false.
     */
    public void run() {
        info(Thread.currentThread().getName() + " id: " + this.id + " started !");
        while (this.alive) {
            try {
                Thread.sleep(500);
                if (Thread.currentThread().getName().equals("P1")) {
                    //
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        cleanup();
        info(Thread.currentThread().getName() + " stopped");
    }

    /**
     * Broadcast a message to all other processes.
     * @param message {@link Message} The message to broadcast.
     * @param <T> {@link T} The type of the message.
     */
    public <T> void broadcast(Message<T> message){
        clock.increment();
        BroadcastMessage<T> broadcastMessage = new BroadcastMessage<>(message.getMessage());
        // Init the timestamp of the message
        broadcastMessage.setTimestamp(clock.get());
        // Init the sender of the message
        broadcastMessage.setSender(this.thread.getName());
        info("Broadcasting message: " + message.getMessage());
        bus.postEvent(broadcastMessage);
    }

    /**
     * Send a message to a specific process.
     * @param to {@link String} The name of the process to send the message to.
     * @param message {@link Message} The message to send.
     * @param <T> {@link T} The type of the message.
     */
    public <T> void sendTo(String to, Message<T> message){
        clock.increment();
        DedicatedMessage<T> dedicatedMessage = new DedicatedMessage<>(message.getMessage());
        // Init the timestamp of the message
        dedicatedMessage.setTimestamp(clock.get());
        // Init the sender of the message
        dedicatedMessage.setSender(this.thread.getName());
        // Init the receiver of the message
        dedicatedMessage.setReceiver(to);
        info("Sending message: " + message.getMessage() + " to " + to);
        bus.postEvent(dedicatedMessage);
    }

    public void sendTokenToNextProcess(TokenMessage<?> tokenMessage){
        String nextProcess = "P" + (this.id + 1) % Process.maxNbProcess;
        tokenMessage.getToken().setHolder(nextProcess);
        sendTo(nextProcess, tokenMessage);
        bus.postEvent(tokenMessage);
    }

    // =====================================
    //             Process Logic
    // =====================================

    /**
     * Clean up resources and unregister the process from the EventBus.
     */
    private void cleanup(){
        this.bus.unRegisterSubscriber(this);
        this.bus = null;
        this.dead = true;
    }

    /**
     * Wait until the process is fully stopped (has reached the dead state).
     */
    public void waitStopped() {
        while (!this.dead) {
            try {
                Thread.sleep(500);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Stop the process by setting the alive flag to false.
     */
    public void stop() {
        this.alive = false;
        info("Process stopped");
    }

    // =====================================
    //             Logging
    // =====================================

    /**
     * Logs a message with the thread name prepended for context.
     * @param message The message to log.
     */
    private void info(String message) {
        System.out.println("[Process " + thread.getName() + "] " + message);
    }

    /**
     * Logs an error message with an exception.
     * @param message The error message.
     * @param e The exception that was thrown.
     */
    private void error(String message, Exception e) {
        System.err.println("[Process " + thread.getName() + "] ERROR: " + message);
        e.printStackTrace();
    }
}
